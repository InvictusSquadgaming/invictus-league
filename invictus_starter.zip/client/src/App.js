
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import axios from "axios";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Matches from "./pages/Matches";
import Leaderboard from "./pages/Leaderboard";
import Bracket from "./pages/Bracket";

function AppInner(){
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(()=>{
    const token = localStorage.getItem("invictus_token");
    if (token) {
      axios.get("http://localhost:5000/api/user/profile", { headers: { Authorization: `Bearer ${token}` } })
        .then(res => setCurrentUser(res.data))
        .catch(()=> localStorage.removeItem("invictus_token"));
    }
  },[]);

  function handleAuth(user){
    setCurrentUser(user);
    window.location.href = "/dashboard";
  }

  function logout(){
    localStorage.removeItem("invictus_token");
    setCurrentUser(null);
    window.location.href = "/";
  }

  return (
    <div style={{padding:20}}>
      <nav style={{display:'flex',gap:12,alignItems:'center',marginBottom:20}}>
        <Link to="/">Home</Link>
        <Link to="/dashboard">Dashboard</Link>
        <Link to="/leaderboard">Leaderboard</Link>
        <Link to="/matches">Matches</Link>
        <Link to="/bracket">Bracket</Link>
        {currentUser ? (
          <>
            <span style={{marginLeft:12}}>{currentUser.gamertag} — {currentUser.points} pts</span>
            <button onClick={logout} style={{marginLeft:8}}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </nav>

      <Routes>
        <Route path="/" element={<div>Welcome to Invictus League. Use the links above.</div>} />
        <Route path="/login" element={<Login onAuth={handleAuth} />} />
        <Route path="/register" element={<Register onAuth={handleAuth} />} />
        <Route path="/dashboard" element={currentUser ? <Dashboard user={currentUser} /> : <div>Please log in.</div>} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="/matches" element={<Matches user={currentUser} refreshParent={()=>{const t=localStorage.getItem("invictus_token"); if(t) window.location.reload();}} />} />
        <Route path="/bracket" element={<Bracket />} />
      </Routes>
    </div>
  );
}

export default function WrappedApp(){ return (<Router><AppInner/></Router>); }
