
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard({ user }){
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    fetch("http://localhost:5000/api/user/leaderboard")
      .then(res=>res.json())
      .then(data => { setLeaderboard(data); setLoading(false); })
      .catch(err => { console.error(err); setLoading(false); });
  },[]);

  return (
    <div>
      <h1>Welcome, {user.gamertag}!</h1>
      <div style={{marginTop:12, padding:12, background:'#071025', borderRadius:8}}>
        <h2>Your Stats</h2>
        <p><strong>Points:</strong> {user.points}</p>
        <p><strong>Rank:</strong> #{leaderboard.findIndex(p=>p._id === user._id) + 1}</p>
      </div>

      <div style={{marginTop:16}}>
        <h2>Leaderboard (Top 20)</h2>
        {loading ? <div>Loading...</div> : (
          <table style={{width:'100%', borderCollapse:'collapse', marginTop:8}}>
            <thead><tr style={{background:'#0b1624'}}><th style={{padding:8}}>Rank</th><th>Gamertag</th><th>Points</th></tr></thead>
            <tbody>
              {leaderboard.slice(0,20).map((p,i)=>(
                <tr key={p._id} style={{background:p._id===user._id? '#15303f':'transparent'}}>
                  <td style={{padding:8}}>{i+1}</td>
                  <td style={{padding:8}}>{p.gamertag}</td>
                  <td style={{padding:8}}>{p.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <button style={{marginTop:12}} onClick={()=>alert("Challenge flow coming soon")}>Challenge Opponent</button>
    </div>
  );
}
