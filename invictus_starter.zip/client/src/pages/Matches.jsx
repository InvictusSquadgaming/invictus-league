
import React, { useEffect, useState } from "react";
import { getMatches, createMatch, confirmMatch, reportWinner, getLeaderboard } from "../api";

export default function Matches({ user, refreshParent }) {
  const [matches, setMatches] = useState([]);
  const [opponentId, setOpponentId] = useState("");
  const [bid, setBid] = useState(100);
  const [players, setPlayers] = useState([]);
  const MIN_BID = 100;

  useEffect(()=>{ load(); },[]);

  async function load(){
    try {
      const [mRes, pRes] = await Promise.all([getMatches(), getLeaderboard()]);
      setMatches(mRes.data.reverse());
      setPlayers(pRes.data.filter(p => p._id !== user?._id));
    } catch (err) { console.error(err); }
  }

  async function handleCreate(){
    if (!user) return alert("Login first");
    if (!opponentId) return alert("Select opponent");
    if (bid < MIN_BID) return alert(`Minimum bid is ${MIN_BID}`);
    if (user.points < bid) return alert("You don't have enough points to bid");
    try {
      await createMatch({ player1: user._id, opponentId, bid });
      await load();
      refreshParent?.();
    } catch (err) {
      alert(err.response?.data?.error || "Could not create match");
    }
  }

  async function handleConfirm(matchId){
    try {
      await confirmMatch({ matchId, userId: user._id });
      await load();
      refreshParent?.();
    } catch (err) { alert(err.response?.data?.error || "Could not confirm"); }
  }

  async function handleReport(matchId, winnerId){
    try {
      await reportWinner({ matchId, winnerId });
      await load();
      refreshParent?.();
    } catch (err) { alert(err.response?.data?.error || "Could not report winner"); }
  }

  return (
    <div>
      <h2>Create / Manage Matches</h2>
      <div style={{display:'flex',gap:8,alignItems:'center',marginTop:8}}>
        <select value={opponentId} onChange={e=>setOpponentId(e.target.value)}>
          <option value="">Select opponent</option>
          {players.map(p => <option key={p._id} value={p._id}>{p.gamertag} — {p.points} pts</option>)}
        </select>
        <input type="number" min={MIN_BID} value={bid} onChange={e=>setBid(Number(e.target.value))} />
        <button onClick={handleCreate}>Create Challenge</button>
      </div>

      <div style={{marginTop:12}}>
        <h3>Active Matches</h3>
        {matches.map(m => (
          <div key={m._id} style={{display:'flex',justifyContent:'space-between',padding:8,background:'#071025',marginTop:6,borderRadius:6}}>
            <div>
              <div><strong>{m.player1?.gamertag}</strong> vs <strong>{m.player2?.gamertag}</strong></div>
              <div style={{fontSize:12,opacity:0.8}}>Bid: {m.bid} pts — Status: {m.status}</div>
            </div>
            <div style={{display:'flex',gap:8}}>
              {m.status === "pending" && user && m.player2?._id === user._id && (
                <button onClick={()=>handleConfirm(m._id)}>Confirm</button>
              )}
              {m.status === "active" && user && (
                <>
                  <button onClick={()=>handleReport(m._id, m.player1?._id)}>Report {m.player1?.gamertag} Win</button>
                  <button onClick={()=>handleReport(m._id, m.player2?._id)}>Report {m.player2?.gamertag} Win</button>
                </>
              )}
              {m.status === "completed" && <div>Winner: {m.winner?.gamertag}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
