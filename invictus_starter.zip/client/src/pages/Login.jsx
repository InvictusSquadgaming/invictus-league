
import React, { useState } from "react";
import axios from "axios";

export default function Login({ onAuth }){
  const [form, setForm] = useState({ gamertag:"", password:"" });
  const [msg, setMsg] = useState(null);

  async function handleLogin(e){
    e.preventDefault();
    setMsg(null);
    try {
      const res = await axios.post("http://localhost:5000/api/user/login", form);
      localStorage.setItem("invictus_token", res.data.token);
      onAuth(res.data.user);
    } catch (err) {
      setMsg(err.response?.data?.error || "Login failed");
    }
  }

  return (
    <div style={{maxWidth:480}}>
      <h2>Login</h2>
      {msg && <div style={{color:'salmon'}}>{msg}</div>}
      <form onSubmit={handleLogin} style={{display:'grid',gap:8}}>
        <input placeholder="Gamertag" value={form.gamertag} onChange={e=>setForm({...form, gamertag:e.target.value})} required />
        <input placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} required />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
