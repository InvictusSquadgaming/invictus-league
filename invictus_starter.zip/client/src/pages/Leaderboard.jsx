
import React, { useEffect, useState } from "react";
import { getLeaderboard } from "../api";

export default function Leaderboard(){
  const [list, setList] = useState([]);
  useEffect(()=>{ load(); const ii=setInterval(load,10000); return ()=>clearInterval(ii); },[]);
  async function load(){ try { const res = await getLeaderboard(); setList(res.data); } catch(e){console.error(e);} }
  return (
    <div>
      <h2>Leaderboard - Top Players</h2>
      <ol>
        {list.map((p,i)=>(<li key={p._id}>{i+1}. {p.gamertag} — {p.points} pts</li>))}
      </ol>
    </div>
  );
}
