
import React, { useState } from "react";
import axios from "axios";

export default function Register({ onAuth }){
  const [form, setForm] = useState({ gamertag:"", email:"", password:"", dob:"", under17:false, parentName:"", parentEmail:"", nonProConfirmed:true });
  const [msg, setMsg] = useState(null);

  async function handleSubmit(e){
    e.preventDefault();
    setMsg(null);
    try {
      const res = await axios.post("http://localhost:5000/api/user/register", form);
      localStorage.setItem("invictus_token", res.data.token);
      onAuth(res.data.user);
    } catch (err) {
      setMsg(err.response?.data?.error || "Registration failed");
    }
  }

  return (
    <div style={{maxWidth:640}}>
      <h2>Register</h2>
      {msg && <div style={{color:'salmon'}}>{msg}</div>}
      <form onSubmit={handleSubmit} style={{display:'grid',gap:8}}>
        <input placeholder="Gamertag" value={form.gamertag} onChange={e=>setForm({...form, gamertag:e.target.value})} required />
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} required />
        <label>Date of birth: <input type="date" value={form.dob} onChange={e=>setForm({...form, dob:e.target.value})} required /></label>
        <label><input type="checkbox" checked={form.under17} onChange={e=>setForm({...form, under17:e.target.checked})} /> I am under 17</label>
        {form.under17 && <>
          <input placeholder="Parent/Guardian name" value={form.parentName} onChange={e=>setForm({...form, parentName:e.target.value})} required />
          <input placeholder="Parent/Guardian email" value={form.parentEmail} onChange={e=>setForm({...form, parentEmail:e.target.value})} required />
        </>}
        <label><input type="checkbox" checked={form.nonProConfirmed} onChange={e=>setForm({...form, nonProConfirmed:e.target.checked})} /> I confirm I have not been a pro esports winner</label>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
