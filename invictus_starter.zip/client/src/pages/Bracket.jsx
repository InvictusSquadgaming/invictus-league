
import React, { useEffect, useState } from "react";
import { getTournaments, seasonCut } from "../api";

export default function Bracket(){
  const [tournaments, setTournaments] = useState([]);
  const [message, setMessage] = useState("");
  useEffect(()=>{ load(); },[]);
  async function load(){ try { const res = await getTournaments(); setTournaments(res.data); } catch(e){console.error(e);} }
  async function runSeasonCut(){ try { const r = await seasonCut(); setMessage(r.data.message || "Season cut created"); await load(); } catch (err) { setMessage(err.response?.data?.error || "Error"); } }
  const tour = tournaments[0];
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h2>Tournament / Bracket</h2>
        <button onClick={runSeasonCut}>Run Season Cut (admin)</button>
      </div>
      {message && <div style={{marginTop:8}}>{message}</div>}
      {!tour ? <div>No tournaments yet.</div> : (
        <div>
          <h3>{tour.name}</h3>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,marginTop:8}}>
            {tour.players?.map(p => <div key={p._id} style={{padding:8,background:'#071025',borderRadius:6}}>{p.gamertag}</div>)}
          </div>
        </div>
      )}
    </div>
  );
}
