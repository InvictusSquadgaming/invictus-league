
import axios from "axios";
const API = axios.create({ baseURL: "http://localhost:5000/api" });

export const registerUser = (data) => API.post("/user/register", data);
export const loginUser = (data) => API.post("/user/login", data);
export const getProfile = (token) => API.get("/user/profile", { headers: { Authorization: `Bearer ${token}` } });
export const getLeaderboard = () => API.get("/user/leaderboard");

export const getTournaments = () => API.get("/tournament");
export const createTournament = (data) => API.post("/tournament", data);
export const joinTournament = (data) => API.post("/tournament/join", data);
export const seasonCut = () => API.post("/tournament/season-cut");

export const getMatches = () => API.get("/match");
export const createMatch = (data) => API.post("/match", data);
export const confirmMatch = (data) => API.post("/match/confirm", data);
export const reportWinner = (data) => API.post("/match/winner", data);
