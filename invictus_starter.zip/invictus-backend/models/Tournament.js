const mongoose = require("mongoose");

const TournamentSchema = new mongoose.Schema({
  name: String,
  type: String,
  category: String,
  entryFee: Number,
  players: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  status: { type: String, default: "upcoming" },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Tournament", TournamentSchema);