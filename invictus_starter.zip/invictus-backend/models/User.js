const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  gamertag: { type: String, unique: true, required: true },
  email: { type: String },
  password: { type: String, required: true },
  dob: { type: String },
  parentName: { type: String },
  parentEmail: { type: String },
  under17: { type: Boolean, default: false },
  nonProConfirmed: { type: Boolean, default: true },
  points: { type: Number, default: 2000 },
  role: { type: String, default: "player" },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("User", UserSchema);