const mongoose = require("mongoose");

const MatchSchema = new mongoose.Schema({
  player1: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  player2: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  bid: { type: Number, required: true, min: 100 },
  status: { type: String, enum: ["pending", "active", "completed"], default: "pending" },
  winner: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

module.exports = mongoose.model("Match", MatchSchema);