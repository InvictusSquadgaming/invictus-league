const express = require("express");
const router = express.Router();
const Match = require("../models/Match");
const User = require("../models/User");

// Create match (challenge)
router.post("/", async (req, res) => {
  try {
    const { player1, opponentId, bid } = req.body;
    const p1 = await User.findById(player1);
    const p2 = await User.findById(opponentId);
    if (!p1 || !p2) return res.status(400).json({ error: "Players not found" });
    if (p1.points < bid) return res.status(400).json({ error: "Not enough points to bid" });

    const match = await Match.create({ player1, player2: opponentId, bid });
    res.json(match);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Confirm match (opponent accepts)
router.post("/confirm", async (req, res) => {
  try {
    const { matchId, userId } = req.body;
    const match = await Match.findById(matchId);
    if (!match) return res.status(404).json({ error: "Match not found" });
    if (match.player2.toString() !== userId) return res.status(403).json({ error: "Only challenged player can confirm" });
    const player2 = await User.findById(userId);
    if (player2.points < match.bid) return res.status(400).json({ error: "Not enough points to confirm" });
    match.status = "active";
    await match.save();
    res.json(match);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Report winner
router.post("/winner", async (req, res) => {
  try {
    const { matchId, winnerId } = req.body;
    const match = await Match.findById(matchId);
    if (!match) return res.status(404).json({ error: "Match not found" });
    if (match.status !== "active") return res.status(400).json({ error: "Match not active" });

    const p1 = await User.findById(match.player1);
    const p2 = await User.findById(match.player2);
    const winner = await User.findById(winnerId);
    if (!winner) return res.status(400).json({ error: "Winner not found" });
    const loser = winnerId === p1.id ? p2 : p1;

    // Transfer points
    loser.points -= match.bid;
    winner.points += match.bid;

    match.status = "completed";
    match.winner = winnerId;

    await p1.save();
    await p2.save();
    await match.save();

    res.json({ match, winner, loser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// list matches
router.get("/", async (req, res) => {
  const matches = await Match.find()
    .populate("player1", "gamertag")
    .populate("player2", "gamertag")
    .populate("winner", "gamertag");
  res.json(matches);
});

module.exports = router;