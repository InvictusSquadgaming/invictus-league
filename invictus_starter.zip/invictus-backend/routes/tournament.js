const express = require("express");
const router = express.Router();
const Tournament = require("../models/Tournament");
const User = require("../models/User");

// create tournament (admin)
router.post("/", async (req, res) => {
  const { name, type, category, entryFee } = req.body;
  const tour = await Tournament.create({ name, type, category, entryFee });
  res.json(tour);
});

// join tournament
router.post("/join", async (req, res) => {
  const { tournamentId, userId } = req.body;
  const tour = await Tournament.findById(tournamentId);
  if (!tour) return res.status(404).json({ error: "Tournament not found" });
  if (tour.players.includes(userId)) return res.status(400).json({ error: "Already joined" });
  tour.players.push(userId);
  await tour.save();
  res.json(tour);
});

// list tournaments
router.get("/", async (req, res) => {
  const tours = await Tournament.find().populate("players", "gamertag");
  res.json(tours);
});

// season cut: top 20 -> tournament
router.post("/season-cut", async (req, res) => {
  try {
    const top20 = await User.find().sort({ points: -1 }).limit(20);
    const tournament = await Tournament.create({
      name: "Invictus Singles Season",
      players: top20.map(p => p._id),
      category: "singles",
      type: "single"
    });
    res.json({ message: "Season cut completed", tournament });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;