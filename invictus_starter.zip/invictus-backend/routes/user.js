const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const JWT_SECRET = process.env.JWT_SECRET || "VERY_SECRET_KEY_CHANGE_ME";
const JWT_EXPIRES = "7d";

function authMiddleware(req, res, next) {
  const token = req.headers["authorization"]?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token provided" });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid token" });
  }
}

router.post("/register", async (req, res) => {
  try {
    const {
      gamertag,
      email,
      password,
      dob,
      under17 = false,
      parentName,
      parentEmail,
      nonProConfirmed = true,
    } = req.body;

    if (!gamertag || !password || !dob)
      return res.status(400).json({ error: "gamertag, password and dob required" });

    const birth = new Date(dob);
    if (isNaN(birth.getTime())) return res.status(400).json({ error: "Invalid dob" });
    const age = Math.floor((Date.now() - birth.getTime()) / (365.25 * 24 * 60 * 60 * 1000));
    if (age < 15) return res.status(400).json({ error: "Minimum age for ranked competition is 15" });
    if (age < 17 && (!parentName || !parentEmail))
      return res.status(400).json({ error: "Parent/guardian info required if under 17" });

    if (!nonProConfirmed)
      return res.status(400).json({ error: "You must confirm you are NOT a professional esports winner" });

    const existing = await User.findOne({ gamertag: gamertag.trim() });
    if (existing) return res.status(400).json({ error: "Gamertag already taken" });

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({
      gamertag: gamertag.trim(),
      email,
      password: hashed,
      dob,
      under17,
      parentName,
      parentEmail,
      nonProConfirmed,
      points: 2000,
    });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    const safe = { _id: user._id, gamertag: user.gamertag, points: user.points };
    res.json({ token, user: safe });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { gamertag, password } = req.body;
    if (!gamertag || !password) return res.status(400).json({ error: "Provide gamertag and password" });

    const user = await User.findOne({ gamertag: gamertag.trim() });
    if (!user) return res.status(400).json({ error: "Invalid gamertag or password" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ error: "Invalid gamertag or password" });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    const safe = { _id: user._id, gamertag: user.gamertag, points: user.points };
    res.json({ token, user: safe });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/profile", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select("-password");
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/leaderboard", async (req, res) => {
  try {
    const players = await User.find().sort({ points: -1 }).limit(50).select("gamertag points");
    res.json(players);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;